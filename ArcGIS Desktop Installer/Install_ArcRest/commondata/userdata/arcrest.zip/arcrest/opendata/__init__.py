"""
initializer code.
"""
from __future__ import absolute_import
from .opendata import OpenDataItem, OpenData
from ._web import WebOperations