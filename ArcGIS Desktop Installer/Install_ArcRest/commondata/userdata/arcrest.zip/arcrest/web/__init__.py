"""
   _web constructor
"""
from __future__ import absolute_import
from . import _base
__version__ = "3.5.6"