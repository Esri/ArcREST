from __future__ import absolute_import
from ...ags._geocodeservice import GeocodeService

class geocode(GeocodeService):
    """ agol geocode object """
    pass