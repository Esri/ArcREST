from __future__ import absolute_import
from .service import AdminFeatureService, AdminFeatureServiceLayer, AdminMapService, Services
__version__ = "3.5.6"