from __future__ import absolute_import
from .geometryservice import GeometryService

__version__ = "3.5.6"